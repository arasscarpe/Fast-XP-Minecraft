package fastxp;

import fastxp.config.FastXPConfig;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

@Environment(EnvType.CLIENT)
public class FastXPClient implements ClientModInitializer {

    private double tickAccumulator = 0.0;

    @Override
    public void onInitializeClient() {
        registerCommands();
        registerTickEvent();
    }

    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("xpbottle")
                .then(ClientCommandManager.literal("on").executes(context -> {
                    FastXPConfig.enabled = true;
                    context.getSource().sendFeedback(class_2561.method_43470("§a[FastXP] Enabled"));
                    return 1;
                }))
                .then(ClientCommandManager.literal("off").executes(context -> {
                    FastXPConfig.enabled = false;
                    context.getSource().sendFeedback(class_2561.method_43470("§c[FastXP] Disabled"));
                    return 1;
                }))
                .then(ClientCommandManager.literal("maxcps")
                    .then(ClientCommandManager.argument("cps", IntegerArgumentType.integer(0, 50))
                        .executes(context -> {
                            int cps = IntegerArgumentType.getInteger(context, "cps");
                            FastXPConfig.maxCps = cps;
                            context.getSource().sendFeedback(class_2561.method_43470("§e[FastXP] Max CPS set to " + cps));
                            return 1;
                        })))
            );
        });
    }

    private void registerTickEvent() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1687 == null) return;
            if (!FastXPConfig.enabled || FastXPConfig.maxCps <= 0) return;

            boolean holdingMain = client.field_1724.method_6047().method_31574(class_1802.field_8287);
            boolean holdingOff = client.field_1724.method_6079().method_31574(class_1802.field_8287);

            if ((holdingMain || holdingOff) && client.field_1690.field_1904.method_1434()) {
                double usesPerTick = FastXPConfig.maxCps / 20.0;
                tickAccumulator += usesPerTick;

                while (tickAccumulator >= 1.0) {
                    class_1268 hand = holdingMain ? class_1268.field_5808 : class_1268.field_5810;
                    client.field_1761.method_2919(client.field_1724, hand);
                    tickAccumulator -= 1.0;
                }
            } else {
                tickAccumulator = 0.0;
            }
        });
    }
}